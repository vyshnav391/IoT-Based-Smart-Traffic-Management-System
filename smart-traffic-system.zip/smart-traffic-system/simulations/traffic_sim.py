#!/usr/bin/env python3
"""
traffic_sim.py — Smart Traffic Management System Simulator
Simulates Arduino traffic controller logic in Python for rapid testing.

Usage:
    python traffic_sim.py --lanes 4 --cycles 20 --scenario peak_hour
    python traffic_sim.py --scenario random --cycles 50 --verbose
"""

import argparse
import random
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import List


# ─── Configuration ──────────────────────────────────────────────────────────
GREEN_MIN_S      = 3.0
GREEN_MAX_S      = 10.0
YELLOW_S         = 2.0
ALL_RED_S        = 0.5
EMERGENCY_S      = 15.0
SENSOR_MAX       = 1023


# ─── Data Structures ────────────────────────────────────────────────────────
class SignalState(Enum):
    RED    = "🔴 RED"
    YELLOW = "🟡 YLW"
    GREEN  = "🟢 GRN"


@dataclass
class Lane:
    name:          str
    density_raw:   int   = 0
    density_score: int   = 0
    signal:        SignalState = SignalState.RED
    total_green_time: float = 0.0
    green_cycles:  int   = 0


@dataclass
class SimStats:
    total_cycles:        int   = 0
    total_sim_time_s:    float = 0.0
    emergency_events:    int   = 0
    avg_green_per_lane:  dict  = field(default_factory=dict)


# ─── Scenario Generators ────────────────────────────────────────────────────
SCENARIOS = {
    "random":       lambda: [random.randint(0, SENSOR_MAX) for _ in range(4)],
    "peak_hour":    lambda: [random.randint(700, 1023),
                             random.randint(600, 900),
                             random.randint(500, 850),
                             random.randint(650, 950)],
    "off_peak":     lambda: [random.randint(0, 400) for _ in range(4)],
    "imbalanced":   lambda: [random.randint(800, 1023),
                             random.randint(0, 200),
                             random.randint(0, 200),
                             random.randint(0, 200)],
    "uniform":      lambda: [600, 600, 600, 600],
}


# ─── Simulator Core ─────────────────────────────────────────────────────────
class TrafficSimulator:
    def __init__(self, n_lanes: int = 4, scenario: str = "random",
                 emergency_prob: float = 0.05, verbose: bool = False):
        lane_names = ["North", "East", "South", "West"][:n_lanes]
        self.lanes   = [Lane(name=n) for n in lane_names]
        self.scenario_fn = SCENARIOS.get(scenario, SCENARIOS["random"])
        self.emergency_prob = emergency_prob
        self.verbose = verbose
        self.stats   = SimStats()
        self.stats.avg_green_per_lane = {l.name: [] for l in self.lanes}

    # ── Sensor simulation ────────────────────────────────────────────────────
    def read_sensors(self):
        readings = self.scenario_fn()
        for i, lane in enumerate(self.lanes):
            lane.density_raw = readings[i] if i < len(readings) else 0

    def compute_scores(self):
        vals = [l.density_raw for l in self.lanes]
        min_v, max_v = min(vals), max(vals)
        spread = max_v - min_v or 1
        for lane in self.lanes:
            lane.density_score = int((lane.density_raw - min_v) / spread * 100)

    # ── Signal logic ─────────────────────────────────────────────────────────
    def select_highest(self) -> Lane:
        return max(self.lanes, key=lambda l: l.density_score)

    def compute_green_time(self, lane: Lane) -> float:
        ratio = lane.density_score / 100.0
        return GREEN_MIN_S + ratio * (GREEN_MAX_S - GREEN_MIN_S)

    def all_red(self):
        for lane in self.lanes:
            lane.signal = SignalState.RED

    def run_green_phase(self, lane: Lane):
        green_s = self.compute_green_time(lane)
        lane.signal = SignalState.GREEN
        lane.total_green_time += green_s
        lane.green_cycles += 1
        self.stats.avg_green_per_lane[lane.name].append(green_s)
        self.stats.total_sim_time_s += green_s + YELLOW_S + ALL_RED_S

        if self.verbose:
            print(f"  [SIGNAL] {lane.name} GREEN for {green_s:.1f}s (adaptive)")
        lane.signal = SignalState.YELLOW
        if self.verbose:
            print(f"  [SIGNAL] {lane.name} YELLOW for {YELLOW_S:.1f}s")
        self.all_red()

    def handle_emergency(self):
        self.stats.emergency_events += 1
        self.all_red()
        self.stats.total_sim_time_s += EMERGENCY_S
        print("\n  ⚡ [EMERGENCY] Override activated!")
        print(f"  [SERVO] Emergency lane OPEN for {EMERGENCY_S:.0f}s")
        print("  [RESUME] Normal cycle resumed.\n")

    # ── Main simulation loop ─────────────────────────────────────────────────
    def run(self, cycles: int):
        print("=" * 50)
        print("  SMART TRAFFIC SIMULATOR v1.0")
        print(f"  Lanes: {len(self.lanes)} | Cycles: {cycles}")
        print("=" * 50)

        for c in range(1, cycles + 1):
            self.stats.total_cycles += 1

            # Emergency check
            if random.random() < self.emergency_prob:
                self.handle_emergency()
                continue

            # Read & compute
            self.read_sensors()
            self.compute_scores()

            if self.verbose:
                print(f"\n--- Cycle #{c} ---")
                sensor_str = "  ".join(
                    f"{l.name[0]}:{l.density_raw}" for l in self.lanes
                )
                score_str = " ".join(
                    f"{l.name[0]}:{l.density_score}%" for l in self.lanes
                )
                print(f"  [SENSOR]  {sensor_str}")
                print(f"  [DENSITY] {score_str}")

            best = self.select_highest()
            if self.verbose:
                print(f"  [DECISION] → {best.name} ({best.density_score}%)")
            self.run_green_phase(best)

        self.print_summary()

    # ── Results ──────────────────────────────────────────────────────────────
    def print_summary(self):
        print("\n" + "=" * 50)
        print("  SIMULATION SUMMARY")
        print("=" * 50)
        print(f"  Total Cycles:       {self.stats.total_cycles}")
        print(f"  Emergency Events:   {self.stats.emergency_events}")
        print(f"  Total Sim Time:     {self.stats.total_sim_time_s:.1f}s\n")
        print("  Per-Lane Statistics:")
        print(f"  {'Lane':<10} {'Green Cycles':>14} {'Avg Green (s)':>14} {'Total Green (s)':>16}")
        print("  " + "-" * 56)
        for lane in self.lanes:
            times = self.stats.avg_green_per_lane[lane.name]
            avg = sum(times) / len(times) if times else 0
            print(f"  {lane.name:<10} {lane.green_cycles:>14} {avg:>13.1f}s {lane.total_green_time:>15.1f}s")
        print("=" * 50)


# ─── Entry Point ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Smart Traffic Simulator")
    parser.add_argument("--lanes",     type=int,   default=4,          help="Number of lanes (2–4)")
    parser.add_argument("--cycles",    type=int,   default=20,         help="Number of cycles to simulate")
    parser.add_argument("--scenario",  type=str,   default="random",
                        choices=list(SCENARIOS.keys()),                 help="Traffic scenario")
    parser.add_argument("--emergency", type=float, default=0.05,       help="Emergency probability per cycle")
    parser.add_argument("--verbose",   action="store_true",             help="Verbose output")

    args = parser.parse_args()
    sim = TrafficSimulator(
        n_lanes=args.lanes,
        scenario=args.scenario,
        emergency_prob=args.emergency,
        verbose=args.verbose
    )
    sim.run(args.cycles)
