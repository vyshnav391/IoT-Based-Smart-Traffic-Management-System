# Contributing to Smart Traffic Management System

Thank you for your interest in contributing! This document outlines the process for contributing to this project.

## Getting Started

1. **Fork** the repository
2. **Clone** your fork: `git clone https://github.com/YOUR_USERNAME/smart-traffic-system.git`
3. **Create a branch**: `git checkout -b feature/your-feature-name`

## Branch Naming Convention

| Type | Pattern | Example |
|---|---|---|
| New feature | `feature/description` | `feature/wifi-logging` |
| Bug fix | `fix/description` | `fix/sensor-noise` |
| Documentation | `docs/description` | `docs/calibration-guide` |
| Simulation | `sim/description` | `sim/rush-hour-scenario` |

## Commit Message Format

Follow [Conventional Commits](https://www.conventionalcommits.org/):

```
feat: add ESP8266 Wi-Fi data logging
fix: correct servo angle for emergency gate
docs: update wiring schematic for v1.1
test: add density scoring edge case tests
sim: add rush hour traffic scenario
```

## Code Style

**Arduino/C++:**
- Use `#define` constants for all magic numbers (add to `config.h`)
- Comment every function with purpose, parameters, return value
- Use descriptive variable names (`densityScore` not `ds`)
- Keep functions under 40 lines

**Python:**
- Follow PEP 8
- Max line length: 100 characters
- Add docstrings to all classes and functions

## Pull Request Process

1. Ensure CI passes (Arduino build + Python tests)
2. Update `README.md` if you change functionality
3. Add your change to `CHANGELOG.md` under `[Unreleased]`
4. Request review from a maintainer

## Good First Issues

Look for issues tagged `good-first-issue`:
- Improving sensor noise filtering
- Adding new simulation scenarios
- Expanding documentation
- Writing unit tests

## Hardware Contributions

If you test on different hardware:
- Document exact component model numbers
- Note any calibration differences
- Update `hardware/BOM.csv` with alternatives

## Questions?

Open a [Discussion](../../discussions) or file an issue.
