/**
 * config.h — Tunable System Parameters
 * Smart Traffic Management System v1.0
 * 
 * Edit these values to calibrate for your specific hardware setup.
 */

#pragma once

// ─── System ──────────────────────────────────────────────────
#define NUM_LANES           4
#define SERIAL_BAUD         9600

// ─── Timing (milliseconds) ───────────────────────────────────
#define GREEN_MIN_MS        3000    // Minimum green phase duration
#define GREEN_MAX_MS       10000    // Maximum green phase duration
#define YELLOW_MS           2000    // Fixed yellow phase
#define ALL_RED_MS           500    // All-red clearance interval
#define INTER_GREEN_MS       300    // Inter-green safety buffer
#define DENSITY_SAMPLE_MS    500    // How often sensors are polled
#define EMERGENCY_DURATION_MS 15000 // Emergency lane open duration

// ─── Sensor Thresholds (ADC 0–1023) ─────────────────────────
#define DENSITY_LOW         300     // Sparse traffic
#define DENSITY_MEDIUM      600     // Moderate traffic
#define DENSITY_HIGH        800     // Dense traffic

// ─── Servo Angles ────────────────────────────────────────────
#define SERVO_CLOSED_ANGLE    0     // Gate closed position
#define SERVO_OPEN_ANGLE     90     // Gate open (emergency lane)

// ─── LED Pin Assignments ─────────────────────────────────────
//    Lane 1 — North
#define PIN_RED_1           2
#define PIN_YLW_1           3
#define PIN_GRN_1           4

//    Lane 2 — East
#define PIN_RED_2           5
#define PIN_YLW_2           6
#define PIN_GRN_2           7

//    Lane 3 — South
#define PIN_RED_3           8
#define PIN_YLW_3           9
#define PIN_GRN_3          10

//    Lane 4 — West
#define PIN_RED_4          11
#define PIN_YLW_4          12
#define PIN_GRN_4          13

// ─── Sensor & Control Pins ───────────────────────────────────
#define PIN_SENSOR_1        A0
#define PIN_SENSOR_2        A1
#define PIN_SENSOR_3        A2
#define PIN_SENSOR_4        A3
#define PIN_EMERGENCY_BTN   A4
#define PIN_SERVO           A5
