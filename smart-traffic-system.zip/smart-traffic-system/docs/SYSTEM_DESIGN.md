# System Design — Smart Traffic Management System

## Overview

This document provides an in-depth explanation of the system architecture, algorithmic decisions, and design trade-offs for the IoT-Based Smart Traffic Management System.

---

## Adaptive Timing Algorithm

### Problem with Fixed-Cycle Signals

Traditional traffic lights operate on fixed timers (e.g., 30s green regardless of traffic). This causes:
- Empty roads getting full green time while congested lanes wait
- No differentiation between 3am and 5pm rush hour

### Our Approach: Proportional Density Scoring

Each cycle, the system:

1. **Samples** all 4 sensor ADC values (0–1023)
2. **Normalizes** them to a 0–100 score relative to the current cycle's min/max
3. **Selects** the lane with the highest score for green phase
4. **Scales** green duration: `green_ms = MIN + (score/100) × (MAX - MIN)`

This means a lane at 100% score gets `GREEN_MAX_MS` (10s), while a lane at 0% would get `GREEN_MIN_MS` (3s).

### Why Proportional vs Absolute Thresholds?

Absolute thresholds (`if sensor > 800, extend green`) are brittle — they break when ambient light changes (LDRs are light-sensitive). Proportional normalization is **self-calibrating** each cycle, making the system resilient to:
- Time-of-day lighting changes
- Seasonal variations
- Different deployment environments

---

## Emergency Override Design

### Requirements
- Immediate response (interrupt any active phase)
- Dedicated physical lane (servo-actuated gate)
- Automatic recovery to normal operation

### Implementation
The emergency button is polled inside the green phase loop every 50ms, providing worst-case 50ms response latency — well within real-world tolerances.

The servo opens an emergency lane (orthogonal to main signal lanes) for `EMERGENCY_DURATION_MS` (default 15s), then auto-closes and resumes normal scheduling.

### Trade-offs
- **Polling vs Hardware Interrupt:** We use polling rather than `attachInterrupt()` to avoid race conditions with the Servo library's timer usage. Polling inside the green phase loop provides adequate responsiveness.

---

## Sensor Selection: LDR vs IR

| Property | LDR | IR Module |
|---|---|---|
| Cost | Very low (~$0.10) | Low (~$1.50) |
| Noise sensitivity | High (light-dependent) | Low |
| Vehicle detection accuracy | Indirect (shadow-based) | Direct (beam break) |
| Outdoor viability | Poor | Good |
| Prototype suitability | Excellent | Good |

For this prototype, LDRs suffice to demonstrate the concept. Production deployment would use IR or ultrasonic sensors.

---

## Future Architecture: v2.0 with Wi-Fi

```
┌─────────────┐    MQTT     ┌─────────────────┐    HTTP    ┌──────────────┐
│ Arduino UNO │────────────▶│  MQTT Broker    │───────────▶│  Dashboard   │
│ + ESP8266   │             │  (Mosquitto /   │            │  (ThingSpeak │
│             │             │   AWS IoT)      │            │   / Grafana) │
└─────────────┘             └─────────────────┘            └──────────────┘
                                     │
                                     ▼
                            ┌─────────────────┐
                            │  Mobile App     │
                            │  (Flutter)      │
                            │  - Live view    │
                            │  - Override btn │
                            └─────────────────┘
```

### MQTT Topics (planned)
```
traffic/lane/1/density     → {"raw": 782, "score": 76, "timestamp": 1234567}
traffic/lane/1/signal      → {"state": "GREEN", "duration_ms": 8400}
traffic/system/emergency   → {"active": true, "triggered_at": 1234567}
traffic/system/stats       → {"cycle": 42, "uptime_s": 3600}
```
