---
name: Bug Report
about: Report a hardware or software issue
title: '[BUG] '
labels: bug
assignees: ''
---

## Bug Description
A clear description of the issue.

## Hardware Setup
- Arduino board version: 
- Sensor type (LDR/IR): 
- Servo model: 
- Power source: 

## Steps to Reproduce
1. 
2. 
3. 

## Expected Behavior
What should happen.

## Actual Behavior
What actually happens.

## Serial Monitor Output
```
Paste serial output here
```

## Additional Context
Photos of your wiring, oscilloscope captures, etc.
