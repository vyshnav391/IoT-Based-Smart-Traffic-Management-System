# Pin Mapping Reference

## Arduino UNO — Complete Pin Assignment

### Digital Output Pins — LED Traffic Signals

| Pin | Lane | Direction | Color  | Notes              |
|-----|------|-----------|--------|--------------------|
| D2  | 1    | North     | Red    | 220Ω series resistor |
| D3  | 1    | North     | Yellow | 220Ω series resistor |
| D4  | 1    | North     | Green  | 220Ω series resistor |
| D5  | 2    | East      | Red    | 220Ω series resistor |
| D6  | 2    | East      | Yellow | 220Ω series resistor |
| D7  | 2    | East      | Green  | 220Ω series resistor |
| D8  | 3    | South     | Red    | 220Ω series resistor |
| D9  | 3    | South     | Yellow | 220Ω series resistor |
| D10 | 3    | South     | Green  | 220Ω series resistor |
| D11 | 4    | West      | Red    | 220Ω series resistor |
| D12 | 4    | West      | Yellow | 220Ω series resistor |
| D13 | 4    | West      | Green  | 220Ω series resistor |

> **LED Resistor Calculation:**  
> Arduino output = 5V, LED forward voltage ≈ 2.0V, target current = 15mA  
> R = (5.0 - 2.0) / 0.015 = 200Ω → use 220Ω (next standard value)

---

### Analog Input Pins — LDR Density Sensors

| Pin | Lane | Direction | Notes                               |
|-----|------|-----------|-------------------------------------|
| A0  | 1    | North     | 10kΩ pull-down to GND, LDR to 5V   |
| A1  | 2    | East      | 10kΩ pull-down to GND, LDR to 5V   |
| A2  | 3    | South     | 10kΩ pull-down to GND, LDR to 5V   |
| A3  | 4    | West      | 10kΩ pull-down to GND, LDR to 5V   |

> **LDR Voltage Divider:**  
> More light (more vehicles) → LDR resistance ↓ → A0 voltage ↑ → higher ADC reading  
> Configure `DENSITY_HIGH` threshold in `config.h` to match ambient light.

---

### Control Pins

| Pin | Function            | Mode          | Notes                            |
|-----|---------------------|---------------|----------------------------------|
| A4  | Emergency Button    | INPUT_PULLUP  | Active LOW; connect BTN to GND   |
| A5  | Servo Motor Signal  | OUTPUT (PWM)  | SG90 signal wire; VCC to 5V rail |

---

### Power Requirements

| Rail | Current Draw | Source          |
|------|-------------|-----------------|
| 5V   | ~200mA      | USB / Vin reg   |
| Servo peak | ~500mA | External 5V recommended |

> ⚠️ **Note:** When using a servo, power it from an external 5V supply (not Arduino 5V pin) to avoid brownout resets during servo movement.
