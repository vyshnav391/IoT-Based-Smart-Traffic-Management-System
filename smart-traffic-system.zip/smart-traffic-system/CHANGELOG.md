# Changelog

All notable changes to this project are documented here.  
Format: [Keep a Changelog](https://keepachangelog.com/) | Versioning: [SemVer](https://semver.org/)

---

## [Unreleased]
### Planned
- ESP8266 Wi-Fi integration for cloud data logging
- MQTT support for IoT dashboards
- SD card logging module
- Multi-intersection I2C coordination

---

## [1.0.0] — 2024-xx-xx
### Added
- Initial release — fully functional prototype
- 4-lane adaptive traffic signal control via LDR sensors
- Proportional green time algorithm based on real-time density
- Emergency vehicle override with SG90 servo motor gate
- Serial monitor logging at 9600 baud
- Python traffic flow simulator with 5 scenario types
- Self-test routine on startup
- Sensor noise reduction via 3-sample averaging
- Full Arduino CI build via GitHub Actions
- Comprehensive README with architecture diagrams and wiring schematics
- Bill of Materials (BOM.csv)
- Pin mapping documentation
- MIT License

### Architecture
- ATmega328P (Arduino UNO) @ 16MHz
- Analog sensor input on A0–A3
- Digital LED output on pins 2–13
- Servo on A5, emergency button on A4

---

[Unreleased]: https://github.com/YOUR_USERNAME/smart-traffic-system/compare/v1.0.0...HEAD
[1.0.0]: https://github.com/YOUR_USERNAME/smart-traffic-system/releases/tag/v1.0.0
